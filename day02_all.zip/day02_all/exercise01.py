#练习　画内存图
a = 'A'
b = 'B'
a = b
b = 'C'
print('变量a的值是：',a)