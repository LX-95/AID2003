'''
增强运算
'''

num = 200
# print(num+1)#201
# print(num)  #200

#增强运算
#累加
#变量的值加上另外一个数 再赋值给自身变量
#num = num + 1
num += 1
print(num)

num -= 1
#num = num - 1

num *= 2
# num = num*2









