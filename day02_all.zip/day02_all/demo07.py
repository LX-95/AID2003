'''
比较运算
逻辑运算
'''
#结果 bool
#True 对的 满足条件
#False 不对的 不满足条件
# print(10>20)
# print(2!=1)
#
# print('abc'>'ab')

# *******************
#与 and 表示并且 两个结果有一个为假就为假
print(True and True) #True
print(True and False) #False
print(False and True)#False
print(False and False)#False

#或 or 表示或者 两个结果有一个为真就为真
print(True or True) #True
print(True or False) #True
print(False or True)#True
print(False or False)#False

#非 not 取反  not真为假  not假为真
print(not True)
print(not False)









