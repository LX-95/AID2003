"""
    注释
    print
    input
"""

#单行注释　描述代码信息
#input 输入功能
#作用从终端获取输入的信息　存到左边的变量中
#input(提示的字符串)
name = input('请输入姓名')
#print 打印功能
#作用将括号中的内容　显示到终端
print(name)
#使用print()打印多个内容
print('hello',name,'今天天气不错')

#预习 变量＋休息　
#9:45~10:00











