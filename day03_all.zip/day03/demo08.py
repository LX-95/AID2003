'''
规定次数的循环
'''
count = 0
while count<3:
    dol = int(input('请输入美元'))
    print(dol * 6.9)
    count += 1